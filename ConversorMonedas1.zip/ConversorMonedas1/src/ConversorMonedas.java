import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;
import org.json.JSONObject;

public class ConversorMonedas {

    // Mi codigo para obtener las tasas de cambio desde la API
    public static String getExchangeRates() throws Exception {
        String apiKey = "a02844666334fd63f681087f"; // Mi clave API
        String apiUrl = "https://v6.exchangerate-api.com/v6/" + apiKey + "/latest/USD"; // URL de mi API
        URL url = new URL(apiUrl);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("GET");

        // Verifico si la respuesta de mi API es exitosa
        int responseCode = connection.getResponseCode();
        if (responseCode != 200) {
            throw new RuntimeException("Error en la solicitud HTTP: " + responseCode);
        }

        BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
        String inputLine;
        StringBuilder content = new StringBuilder();
        while ((inputLine = in.readLine()) != null) {
            content.append(inputLine);
        }
        in.close(); // Cerrar la conexión
        connection.disconnect(); // Desconectar la API

        return content.toString(); // Devolver la respuesta en formato String
    }

    // Mi metodo para convertir los dolares a todas las monedas de la API
    public static void convertirMonedas(double amountInUSD) throws Exception {
        // Obtengo las tasas de cambio desde la API
        String response = getExchangeRates();

        // Parsear la respuesta JSON
        JSONObject jsonResponse = new JSONObject(response);
        JSONObject conversionRates = jsonResponse.getJSONObject("conversion_rates");

        // Recorrer tasas de conversión y mostrar valores convertidos en la consola
        System.out.println("\nConversión de " + amountInUSD + " USD a otras monedas:");
        for (String currencyCode : conversionRates.keySet()) {
            double conversionRate = conversionRates.getDouble(currencyCode);
            double convertedAmount = amountInUSD * conversionRate;
            System.out.printf("%s: %.2f\n", currencyCode, convertedAmount); // Imprimir la tasa de cambio y el monto convertido
        }
    }

    // Método principal para ejecutar el programa
    public static void main(String[] args) {
        try {
            // Solicitar al usuario que ingrese la cantidad en USD
            Scanner scanner = new Scanner(System.in);
            System.out.print("Introduce los dólares a convertir: ");
            double amountInUSD = 0;

            // Verificar entrada válida
            if (scanner.hasNextDouble()) {
                amountInUSD = scanner.nextDouble();
            } else {
                System.out.println("Por favor, introduce un número válido.");
                return;
            }

            // Llamar a mi metodo para convertir monedas
            convertirMonedas(amountInUSD);

        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
            e.printStackTrace(); // Imprimir el error para detalles
        }
    }
}

